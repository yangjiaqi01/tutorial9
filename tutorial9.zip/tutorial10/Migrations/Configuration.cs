﻿namespace tutorial10.Migrations
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using tutorial10.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<tutorial10.Data.tutorial10Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
            ContextKey = "tutorial10.Data.tutorial10Context";
        }

        protected override void Seed(tutorial10.Data.tutorial10Context context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method
            //  to avoid creating duplicate seed data.
            var campuses = new List<UniversityCampus>
{
    new UniversityCampus { Name = "Massey" },
    new UniversityCampus { Name = "Hebut" },
    new UniversityCampus { Name = "Harvard University" },
    new UniversityCampus { Name = "Stanford University" },
    new UniversityCampus { Name = "University of Oxford" },
    new UniversityCampus { Name = "Princeton University" },
    new UniversityCampus { Name = "University of Cambridge" },
    new UniversityCampus { Name = "MIT" },
    new UniversityCampus { Name = "University of Chicago" }
};
            campuses.ForEach(c => context.UniversityCampus.AddOrUpdate(p => p.Name, c));
            context.SaveChanges();
            var students = new List<Student>
{
    new Student { Name = "Lily", Address = "Main Street", CampusID = campuses.Single(c => c.Name == "Massey").ID },
    new Student { Name = "Betsy", Address = "Cuba Street", CampusID = campuses.Single(c => c.Name == "Massey").ID },
    new Student { Name = "Jone", Address = "Worchester Street", CampusID = campuses.Single(c => c.Name == "Hebut").ID },
    new Student { Name = "Jack", Address = "55 Salisbury Street", CampusID = campuses.Single(c => c.Name == "Harvard University").ID },
    new Student { Name = "Justine", Address = "12 Albert Street", CampusID = campuses.Single(c => c.Name == "University of Oxford").ID },
    new Student { Name = "Bob", Address = "100 Main Street", CampusID = campuses.Single(c => c.Name == "MIT").ID },
    new Student { Name = "Mary", Address = "London", CampusID = campuses.Single(c => c.Name == "Stanford University").ID },
    new Student { Name = "Yam", Address = "NewYork", CampusID = campuses.Single(c => c.Name == "University of Chicago").ID },
    new Student { Name = "Candy", Address = "4 Manchester Street Feilding", CampusID = campuses.Single(c => c.Name == "University of Cambridge").ID }
};
            students.ForEach(c => context.Students.AddOrUpdate(p => p.Name, c));
            context.SaveChanges();
        }
    }
}
