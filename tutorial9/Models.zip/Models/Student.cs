﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace tutorial7.Models
{
    public class Student
    {
        [Key]
        public int ID { get; set; }
        [Required(ErrorMessage = "The student name cannot be blank")]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Please enter a student name between 3 and 50 characters in length")]
        [RegularExpression(@"^[a-zA-Z,\s]*$", ErrorMessage = "Please enter a student name made up of only letters and spaces")]
        

        [Display(Name = "Student Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "The student address cannot be blank")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Please enter an address between 5 and 100 characters in length")]

        public string Address { get; set; }
        public int? CampusID { get; set; }
        public virtual UniversityCampus Campus { get; set; }
    }
}