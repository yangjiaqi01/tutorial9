﻿//namespace tutorial7.Migrations
//{
//    using System;
//    using System.Data.Entity.Migrations;
    
//    public partial class AddNewField : DbMigration
//    {
//        public override void Up()
//        {
//            DropForeignKey("dbo.Students", "CampusID", "dbo.UniversityCampus");
//            DropIndex("dbo.Students", new[] { "CampusID" });
//            AlterColumn("dbo.Students", "CampusID", c => c.Int());
//            CreateIndex("dbo.Students", "CampusID");
//            AddForeignKey("dbo.Students", "CampusID", "dbo.UniversityCampus", "ID");
//        }
        
//        public override void Down()
//        {
//            DropForeignKey("dbo.Students", "CampusID", "dbo.UniversityCampus");
//            DropIndex("dbo.Students", new[] { "CampusID" });
//            AlterColumn("dbo.Students", "CampusID", c => c.Int(nullable: false));
//            CreateIndex("dbo.Students", "CampusID");
//            AddForeignKey("dbo.Students", "CampusID", "dbo.UniversityCampus", "ID", cascadeDelete: true);
//        }
//    }
//}
